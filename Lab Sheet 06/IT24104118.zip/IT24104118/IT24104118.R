setwd('C:/Users/CYBORG/OneDrive/Desktop/IT24104118')
getwd()

# Question 01

# i.X ~ Binomial(n = 50, p = 0.85)

n <- 50       # number of students
p <- 0.85     # probability of passing

# ii. P(X >= 47) = 1 - P(X <= 46)

prob_at_least_47 <- sum(dbinom(47:50, size = n, prob = p))
print(paste("P(X >= 47):", prob_at_least_47))

#Question 02

#i.X = Number of customer calls received in one hour

#ii. X ~ Poisson(lambda = 12)

lambda <- 12  # average calls per hour

# iii. P(X = 15)
prob_15_calls <- dpois(15, lambda = lambda)
print(paste("P(X = 15):", prob_15_calls))
